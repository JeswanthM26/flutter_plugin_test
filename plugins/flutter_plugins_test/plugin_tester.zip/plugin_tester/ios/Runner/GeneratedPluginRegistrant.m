//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<apz_app_switch/ApzAppSwitch.h>)
#import <apz_app_switch/ApzAppSwitch.h>
#else
@import apz_app_switch;
#endif

#if __has_include(<apz_contact/ApzContact.h>)
#import <apz_contact/ApzContact.h>
#else
@import apz_contact;
#endif

#if __has_include(<apz_contact_picker/ApzContactPicker.h>)
#import <apz_contact_picker/ApzContactPicker.h>
#else
@import apz_contact_picker;
#endif

#if __has_include(<apz_deeplink/Deeplink.h>)
#import <apz_deeplink/Deeplink.h>
#else
@import apz_deeplink;
#endif

#if __has_include(<apz_device_fingerprint/ApzDeviceFingerprint.h>)
#import <apz_device_fingerprint/ApzDeviceFingerprint.h>
#else
@import apz_device_fingerprint;
#endif

#if __has_include(<apz_device_info/ApzDeviceInfo.h>)
#import <apz_device_info/ApzDeviceInfo.h>
#else
@import apz_device_info;
#endif

#if __has_include(<apz_in_app_review/ApzInAppReview.h>)
#import <apz_in_app_review/ApzInAppReview.h>
#else
@import apz_in_app_review;
#endif

#if __has_include(<apz_network_state/ApzNetworkState.h>)
#import <apz_network_state/ApzNetworkState.h>
#else
@import apz_network_state;
#endif

#if __has_include(<apz_network_state_perm/ApzNetworkStatePerm.h>)
#import <apz_network_state_perm/ApzNetworkStatePerm.h>
#else
@import apz_network_state_perm;
#endif

#if __has_include(<apz_peripherals/ApzPeripheralsPlugin.h>)
#import <apz_peripherals/ApzPeripheralsPlugin.h>
#else
@import apz_peripherals;
#endif

#if __has_include(<apz_screen_security/ApzScreenSecurity.h>)
#import <apz_screen_security/ApzScreenSecurity.h>
#else
@import apz_screen_security;
#endif

#if __has_include(<apz_send_sms/ApzSendSMS.h>)
#import <apz_send_sms/ApzSendSMS.h>
#else
@import apz_send_sms;
#endif

#if __has_include(<camera_avfoundation/CameraPlugin.h>)
#import <camera_avfoundation/CameraPlugin.h>
#else
@import camera_avfoundation;
#endif

#if __has_include(<file_picker/FilePickerPlugin.h>)
#import <file_picker/FilePickerPlugin.h>
#else
@import file_picker;
#endif

#if __has_include(<firebase_core/FLTFirebaseCorePlugin.h>)
#import <firebase_core/FLTFirebaseCorePlugin.h>
#else
@import firebase_core;
#endif

#if __has_include(<firebase_messaging/FLTFirebaseMessagingPlugin.h>)
#import <firebase_messaging/FLTFirebaseMessagingPlugin.h>
#else
@import firebase_messaging;
#endif

#if __has_include(<flutter_doc_scanner/SwiftFlutterDocScannerPlugin.h>)
#import <flutter_doc_scanner/SwiftFlutterDocScannerPlugin.h>
#else
@import flutter_doc_scanner;
#endif

#if __has_include(<flutter_local_notifications/FlutterLocalNotificationsPlugin.h>)
#import <flutter_local_notifications/FlutterLocalNotificationsPlugin.h>
#else
@import flutter_local_notifications;
#endif

#if __has_include(<flutter_secure_storage/FlutterSecureStoragePlugin.h>)
#import <flutter_secure_storage/FlutterSecureStoragePlugin.h>
#else
@import flutter_secure_storage;
#endif

#if __has_include(<geolocator_apple/GeolocatorPlugin.h>)
#import <geolocator_apple/GeolocatorPlugin.h>
#else
@import geolocator_apple;
#endif

#if __has_include(<image_cropper/FLTImageCropperPlugin.h>)
#import <image_cropper/FLTImageCropperPlugin.h>
#else
@import image_cropper;
#endif

#if __has_include(<image_picker_ios/FLTImagePickerPlugin.h>)
#import <image_picker_ios/FLTImagePickerPlugin.h>
#else
@import image_picker_ios;
#endif

#if __has_include(<local_auth_darwin/LocalAuthPlugin.h>)
#import <local_auth_darwin/LocalAuthPlugin.h>
#else
@import local_auth_darwin;
#endif

#if __has_include(<path_provider_foundation/PathProviderPlugin.h>)
#import <path_provider_foundation/PathProviderPlugin.h>
#else
@import path_provider_foundation;
#endif

#if __has_include(<permission_handler_apple/PermissionHandlerPlugin.h>)
#import <permission_handler_apple/PermissionHandlerPlugin.h>
#else
@import permission_handler_apple;
#endif

#if __has_include(<share_plus/FPPSharePlusPlugin.h>)
#import <share_plus/FPPSharePlusPlugin.h>
#else
@import share_plus;
#endif

#if __has_include(<shared_preferences_foundation/SharedPreferencesPlugin.h>)
#import <shared_preferences_foundation/SharedPreferencesPlugin.h>
#else
@import shared_preferences_foundation;
#endif

#if __has_include(<sqflite_darwin/SqflitePlugin.h>)
#import <sqflite_darwin/SqflitePlugin.h>
#else
@import sqflite_darwin;
#endif

#if __has_include(<url_launcher_ios/URLLauncherPlugin.h>)
#import <url_launcher_ios/URLLauncherPlugin.h>
#else
@import url_launcher_ios;
#endif

#if __has_include(<webview_flutter_wkwebview/WebViewFlutterPlugin.h>)
#import <webview_flutter_wkwebview/WebViewFlutterPlugin.h>
#else
@import webview_flutter_wkwebview;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [ApzAppSwitch registerWithRegistrar:[registry registrarForPlugin:@"ApzAppSwitch"]];
  [ApzContact registerWithRegistrar:[registry registrarForPlugin:@"ApzContact"]];
  [ApzContactPicker registerWithRegistrar:[registry registrarForPlugin:@"ApzContactPicker"]];
  [Deeplink registerWithRegistrar:[registry registrarForPlugin:@"Deeplink"]];
  [ApzDeviceFingerprint registerWithRegistrar:[registry registrarForPlugin:@"ApzDeviceFingerprint"]];
  [ApzDeviceInfo registerWithRegistrar:[registry registrarForPlugin:@"ApzDeviceInfo"]];
  [ApzInAppReview registerWithRegistrar:[registry registrarForPlugin:@"ApzInAppReview"]];
  [ApzNetworkState registerWithRegistrar:[registry registrarForPlugin:@"ApzNetworkState"]];
  [ApzNetworkStatePerm registerWithRegistrar:[registry registrarForPlugin:@"ApzNetworkStatePerm"]];
  [ApzPeripheralsPlugin registerWithRegistrar:[registry registrarForPlugin:@"ApzPeripheralsPlugin"]];
  [ApzScreenSecurity registerWithRegistrar:[registry registrarForPlugin:@"ApzScreenSecurity"]];
  [ApzSendSMS registerWithRegistrar:[registry registrarForPlugin:@"ApzSendSMS"]];
  [CameraPlugin registerWithRegistrar:[registry registrarForPlugin:@"CameraPlugin"]];
  [FilePickerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FilePickerPlugin"]];
  [FLTFirebaseCorePlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTFirebaseCorePlugin"]];
  [FLTFirebaseMessagingPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTFirebaseMessagingPlugin"]];
  [SwiftFlutterDocScannerPlugin registerWithRegistrar:[registry registrarForPlugin:@"SwiftFlutterDocScannerPlugin"]];
  [FlutterLocalNotificationsPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterLocalNotificationsPlugin"]];
  [FlutterSecureStoragePlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterSecureStoragePlugin"]];
  [GeolocatorPlugin registerWithRegistrar:[registry registrarForPlugin:@"GeolocatorPlugin"]];
  [FLTImageCropperPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTImageCropperPlugin"]];
  [FLTImagePickerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTImagePickerPlugin"]];
  [LocalAuthPlugin registerWithRegistrar:[registry registrarForPlugin:@"LocalAuthPlugin"]];
  [PathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"PathProviderPlugin"]];
  [PermissionHandlerPlugin registerWithRegistrar:[registry registrarForPlugin:@"PermissionHandlerPlugin"]];
  [FPPSharePlusPlugin registerWithRegistrar:[registry registrarForPlugin:@"FPPSharePlusPlugin"]];
  [SharedPreferencesPlugin registerWithRegistrar:[registry registrarForPlugin:@"SharedPreferencesPlugin"]];
  [SqflitePlugin registerWithRegistrar:[registry registrarForPlugin:@"SqflitePlugin"]];
  [URLLauncherPlugin registerWithRegistrar:[registry registrarForPlugin:@"URLLauncherPlugin"]];
  [WebViewFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"WebViewFlutterPlugin"]];
}

@end
