package com.example.plugin_tester

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
